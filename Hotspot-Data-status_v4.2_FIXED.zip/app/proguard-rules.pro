# Data Reporter Pro - keep rules if minify is enabled later
-keep class com.hotspot.gateway.** { *; }
