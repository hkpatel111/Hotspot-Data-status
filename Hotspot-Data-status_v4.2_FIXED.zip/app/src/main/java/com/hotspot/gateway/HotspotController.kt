package com.hotspot.gateway

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log

/**
 * Best-effort hotspot control.
 * Modern Android restricts programmatic hotspot toggling heavily.
 * Works better on older devices / some OEMs with reflection.
 */
object HotspotController {

    private const val TAG = "HotspotController"

    fun setHotspotEnabled(context: Context, enable: Boolean): Boolean {
        return try {
            val wifiManager = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as WifiManager

            // Try reflection (most common method that still works on many devices)
            val method = wifiManager.javaClass.getMethod(
                "setWifiApEnabled",
                android.net.wifi.WifiConfiguration::class.java,
                Boolean::class.javaPrimitiveType
            )
            method.isAccessible = true
            val result = method.invoke(wifiManager, null, enable) as Boolean
            Log.i(TAG, "setWifiApEnabled($enable) = $result")
            result
        } catch (e: Exception) {
            Log.w(TAG, "Reflection hotspot toggle failed: ${e.message}")
            // Fallback: try starting local-only hotspot (Android 8+) - limited
            if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                tryStartLocalOnly(context)
            } else {
                false
            }
        }
    }

    private fun tryStartLocalOnly(context: Context): Boolean {
        return try {
            val wifiManager = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as WifiManager
            // Local-only hotspot does not provide internet sharing, but can be useful for testing
            wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                    Log.i(TAG, "Local-only hotspot started")
                }
                override fun onFailed(reason: Int) {
                    Log.w(TAG, "Local-only hotspot failed: $reason")
                }
            }, null)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Local-only hotspot error", e)
            false
        }
    }
}
