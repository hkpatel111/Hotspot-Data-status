package com.hotspot.gateway

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DeviceStatusHelper {

    fun getBatteryLevel(context: Context): Int {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
            -1
        }
    }

    fun getNetworkType(context: Context): String {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return "None"
            val caps = cm.getNetworkCapabilities(network) ?: return "Unknown"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                    // Best-effort 5G / LTE detection
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        "Cellular"
                    } else "Mobile"
                }
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Other"
            }
        } catch (e: Exception) {
            "Error"
        }
    }

    fun isHotspotEnabled(context: Context): Boolean {
        // Method 1: Reflection (works on many devices)
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE)
            val method = wifiManager.javaClass.getDeclaredMethod("isWifiApEnabled")
            method.isAccessible = true
            return method.invoke(wifiManager) as Boolean
        } catch (_: Exception) { }

        // Method 2: Settings secure (some OEMs)
        try {
            val setting = Settings.Global.getInt(context.contentResolver, "wifi_ap_state", 0)
            // 13 = enabled on many devices
            return setting == 13 || setting == 11
        } catch (_: Exception) { }

        return false
    }

    fun getFullStatus(context: Context): String {
        val battery = getBatteryLevel(context)
        val network = getNetworkType(context)
        val hotspot = if (isHotspotEnabled(context)) "ON" else "OFF"
        val time = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
        val charging = isCharging(context)

        return buildString {
            append("📊 Data Reporter Pro\n")
            append("⏰ $time\n")
            append("🔋 Battery: $battery%")
            if (charging) append(" (Charging)")
            append("\n")
            append("📶 Network: $network\n")
            append("📡 Hotspot: $hotspot\n")
            append("---\nReply GET_STATUS for update")
        }
    }

    private fun isCharging(context: Context): Boolean {
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
        } catch (e: Exception) {
            false
        }
    }

    fun saveToLog(context: Context, message: String) {
        try {
            val dir = context.getExternalFilesDir(null)?.let { File(it, "DataReporter") }
            dir?.mkdirs()
            val file = File(dir, "data.txt")
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            file.appendText("[$time] $message\n")
        } catch (_: Exception) { }
    }

    fun clearLogs(context: Context) {
        try {
            val dir = context.getExternalFilesDir(null)?.let { File(it, "DataReporter") }
            File(dir, "data.txt").delete()
        } catch (_: Exception) { }
    }
}
