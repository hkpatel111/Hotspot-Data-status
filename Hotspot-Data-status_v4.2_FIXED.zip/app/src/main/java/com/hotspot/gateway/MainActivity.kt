package com.hotspot.gateway

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etTargetNumber: TextInputEditText
    private lateinit var etInterval: TextInputEditText
    private lateinit var etBootDelay: TextInputEditText
    private lateinit var switchBootHotspot: SwitchMaterial
    private lateinit var switchCommands: SwitchMaterial
    private lateinit var switchForward: SwitchMaterial
    private lateinit var btnSave: MaterialButton
    private lateinit var btnSendStatus: MaterialButton
    private lateinit var btnRefresh: MaterialButton
    private lateinit var btnClearLogs: MaterialButton
    private lateinit var tvBattery: TextView
    private lateinit var tvNetwork: TextView
    private lateinit var tvHotspot: TextView
    private lateinit var tvLastUpdate: TextView
    private lateinit var tvServiceStatus: TextView

    private val PREFS = "GatewayPrefs"
    private val PERMISSION_REQUEST = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        loadPrefs()
        requestNeededPermissions()
        setupListeners()
        refreshLiveStatus()
    }

    private fun bindViews() {
        etTargetNumber = findViewById(R.id.etTargetNumber)
        etInterval = findViewById(R.id.etInterval)
        etBootDelay = findViewById(R.id.etBootDelay)
        switchBootHotspot = findViewById(R.id.switchBootHotspot)
        switchCommands = findViewById(R.id.switchCommands)
        switchForward = findViewById(R.id.switchForward)
        btnSave = findViewById(R.id.btnSave)
        btnSendStatus = findViewById(R.id.btnSendStatus)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnClearLogs = findViewById(R.id.btnClearLogs)
        tvBattery = findViewById(R.id.tvBattery)
        tvNetwork = findViewById(R.id.tvNetwork)
        tvHotspot = findViewById(R.id.tvHotspot)
        tvLastUpdate = findViewById(R.id.tvLastUpdate)
        tvServiceStatus = findViewById(R.id.tvServiceStatus)
    }

    private fun loadPrefs() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        etTargetNumber.setText(prefs.getString("target_number", ""))
        etInterval.setText(prefs.getInt("interval_mins", 60).toString())
        etBootDelay.setText(prefs.getInt("boot_delay", 30).toString())
        switchBootHotspot.isChecked = prefs.getBoolean("boot_hotspot_enabled", true)
        switchCommands.isChecked = prefs.getBoolean("commands_enabled", true)
        switchForward.isChecked = prefs.getBoolean("forward_enabled", true)
    }

    private fun setupListeners() {
        btnSave.setOnClickListener {
            val number = etTargetNumber.text?.toString()?.trim().orEmpty()
            if (number.isEmpty()) {
                Toast.makeText(this, "Please enter target mobile number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val interval = etInterval.text?.toString()?.toIntOrNull() ?: 60
            val delay = etBootDelay.text?.toString()?.toIntOrNull() ?: 30

            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
                putString("target_number", number)
                putInt("interval_mins", interval.coerceIn(5, 1440))
                putInt("boot_delay", delay.coerceIn(5, 300))
                putBoolean("boot_hotspot_enabled", switchBootHotspot.isChecked)
                putBoolean("commands_enabled", switchCommands.isChecked)
                putBoolean("forward_enabled", switchForward.isChecked)
                apply()
            }

            val serviceIntent = Intent(this, HotspotService::class.java)
            ContextCompat.startForegroundService(this, serviceIntent)
            tvServiceStatus.text = getString(R.string.service_running)
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
            Toast.makeText(this, "Settings saved & service started", Toast.LENGTH_SHORT).show()
        }

        btnSendStatus.setOnClickListener {
            val status = DeviceStatusHelper.getFullStatus(this)
            SmsHelper.sendSms(this, status)
            Toast.makeText(this, "Status SMS queued", Toast.LENGTH_SHORT).show()
        }

        btnRefresh.setOnClickListener {
            refreshLiveStatus()
            Toast.makeText(this, "Status refreshed", Toast.LENGTH_SHORT).show()
        }

        btnClearLogs.setOnClickListener {
            DeviceStatusHelper.clearLogs(this)
            Toast.makeText(this, "Local logs cleared", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshLiveStatus() {
        val battery = DeviceStatusHelper.getBatteryLevel(this)
        val network = DeviceStatusHelper.getNetworkType(this)
        val hotspot = DeviceStatusHelper.isHotspotEnabled(this)

        tvBattery.text = "$battery%"
        tvNetwork.text = network
        tvHotspot.text = if (hotspot) "ON" else "OFF"
        tvHotspot.setTextColor(
            ContextCompat.getColor(
                this,
                if (hotspot) R.color.success else R.color.error
            )
        )
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        tvLastUpdate.text = "Last Update: ${sdf.format(Date())}"
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        val permissions = arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        for (p in permissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed.add(p)
            }
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), PERMISSION_REQUEST)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshLiveStatus()
        // Simple check if service might be running (best-effort)
        tvServiceStatus.text = getString(R.string.service_running)
        tvServiceStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
    }
}
