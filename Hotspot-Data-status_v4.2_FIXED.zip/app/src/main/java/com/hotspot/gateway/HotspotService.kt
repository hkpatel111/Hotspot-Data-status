package com.hotspot.gateway

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.BufferedReader
import java.io.FileReader

class HotspotService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val knownClients = mutableSetOf<String>()
    private val CHANNEL_ID = "DataReporterChannel"
    private var intervalMs = 60 * 60 * 1000L

    private val statusRunnable = object : Runnable {
        override fun run() {
            checkConnectedClients()
            // Optionally auto-send status periodically
            val prefs = getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
            val autoReport = prefs.getBoolean("auto_report", false)
            if (autoReport) {
                val status = DeviceStatusHelper.getFullStatus(this@HotspotService)
                SmsHelper.sendSms(this@HotspotService, status)
            }
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification("Monitoring network & clients…")
        startForeground(1, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "DataReporter::WakeLock"
        ).apply {
            acquire(10 * 60 * 1000L) // 10 min, will be refreshed
        }

        val prefs = getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
        val mins = prefs.getInt("interval_mins", 60).coerceIn(5, 1440)
        intervalMs = mins * 60 * 1000L

        handler.post(statusRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun checkConnectedClients() {
        val current = getConnectedClientsFromARP()
        for (client in current) {
            if (client !in knownClients) {
                knownClients.add(client)
                SmsHelper.sendSms(this, "🆕 New device connected\nIP: $client")
                DeviceStatusHelper.saveToLog(this, "New client: $client")
            }
        }
        // Remove clients that disappeared (optional)
        knownClients.retainAll(current.toSet())
    }

    private fun getConnectedClientsFromARP(): List<String> {
        val clients = mutableListOf<String>()
        try {
            BufferedReader(FileReader("/proc/net/arp")).use { br ->
                br.readLine() // header
                var line: String?
                while (br.readLine().also { line = it } != null) {
                    val tokens = line!!.trim().split(Regex("\\s+"))
                    if (tokens.size >= 4) {
                        val ip = tokens[0]
                        val mac = tokens[3]
                        if (mac != "00:00:00:00:00:00" && !ip.startsWith("192.168.43.")) {
                            // Filter gateway itself sometimes
                        }
                        if (mac != "00:00:00:00:00:00") {
                            clients.add("$ip ($mac)")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return clients
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Data Reporter Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps monitoring alive"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(statusRunnable)
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        super.onDestroy()
    }
}
