package com.hotspot.gateway

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != "android.intent.action.QUICKBOOT_POWERON") {
            return
        }

        val prefs = context.getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
        val bootHotspotEnabled = prefs.getBoolean("boot_hotspot_enabled", true)
        val bootDelaySecs = prefs.getInt("boot_delay", 30).coerceIn(5, 300)

        // Always start the monitoring service
        val serviceIntent = Intent(context, HotspotService::class.java)
        ContextCompat.startForegroundService(context, serviceIntent)

        if (bootHotspotEnabled) {
            Handler(Looper.getMainLooper()).postDelayed({
                val ok = HotspotController.setHotspotEnabled(context, true)
                val msg = if (ok) {
                    "📱 Device booted. Hotspot turned ON after ${bootDelaySecs}s."
                } else {
                    "📱 Device booted. Hotspot request sent (may need manual enable on this device)."
                }
                SmsHelper.sendSms(context, msg)
                DeviceStatusHelper.saveToLog(context, "Boot completed, hotspot attempt: $ok")
            }, bootDelaySecs * 1000L)
        } else {
            Handler(Looper.getMainLooper()).postDelayed({
                SmsHelper.sendSms(context, "📱 Device booted. Service started.")
            }, 15_000L)
        }
    }
}
