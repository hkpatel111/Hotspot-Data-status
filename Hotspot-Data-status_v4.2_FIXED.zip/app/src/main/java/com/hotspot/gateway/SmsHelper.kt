package com.hotspot.gateway

import android.content.Context
import android.telephony.SmsManager
import android.util.Log

object SmsHelper {

    private const val TAG = "SmsHelper"

    fun sendSms(context: Context, message: String) {
        val prefs = context.getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
        val target = prefs.getString("target_number", null) ?: return

        try {
            val smsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            // Split long messages
            val parts = smsManager.divideMessage(message)
            if (parts.size == 1) {
                smsManager.sendTextMessage(target, null, message, null, null)
            } else {
                smsManager.sendMultipartTextMessage(target, null, parts, null, null)
            }
            DeviceStatusHelper.saveToLog(context, "SMS sent to $target: ${message.take(40)}...")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS", e)
            DeviceStatusHelper.saveToLog(context, "SMS failed: ${e.message}")
        }
    }
}
