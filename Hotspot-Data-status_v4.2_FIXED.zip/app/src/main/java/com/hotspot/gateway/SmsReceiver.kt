package com.hotspot.gateway

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = context.getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
        val targetNumber = prefs.getString("target_number", "") ?: ""
        val commandsEnabled = prefs.getBoolean("commands_enabled", true)
        val forwardEnabled = prefs.getBoolean("forward_enabled", true)

        for (sms in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            val sender = sms.displayOriginatingAddress ?: continue
            val body = sms.messageBody?.trim() ?: continue
            val upper = body.uppercase()

            // Normalize numbers for comparison (remove spaces, +, etc. basic)
            val senderClean = sender.replace(Regex("[^0-9]"), "")
            val targetClean = targetNumber.replace(Regex("[^0-9]"), "")

            val isFromTarget = targetClean.isNotEmpty() &&
                    (senderClean.endsWith(targetClean) || targetClean.endsWith(senderClean) ||
                     sender.contains(targetNumber))

            if (isFromTarget && commandsEnabled) {
                when {
                    upper.startsWith("GET_STATUS") || upper == "STATUS" || upper == "5G_CHECK" -> {
                        val status = DeviceStatusHelper.getFullStatus(context)
                        SmsHelper.sendSms(context, status)
                        DeviceStatusHelper.saveToLog(context, "Command: GET_STATUS from $sender")
                    }
                    upper.startsWith("HOTSPOT_ON") || upper == "HOTSPOT ON" -> {
                        val ok = HotspotController.setHotspotEnabled(context, true)
                        SmsHelper.sendSms(context, if (ok) "✅ Hotspot ON requested" else "⚠️ Hotspot ON failed (OEM restriction)")
                        DeviceStatusHelper.saveToLog(context, "Command: HOTSPOT_ON → $ok")
                    }
                    upper.startsWith("HOTSPOT_OFF") || upper == "HOTSPOT OFF" -> {
                        val ok = HotspotController.setHotspotEnabled(context, false)
                        SmsHelper.sendSms(context, if (ok) "✅ Hotspot OFF requested" else "⚠️ Hotspot OFF failed")
                        DeviceStatusHelper.saveToLog(context, "Command: HOTSPOT_OFF → $ok")
                    }
                    else -> {
                        // Unknown command from owner - ignore or reply
                    }
                }
            } else if (forwardEnabled && targetNumber.isNotEmpty() && !isFromTarget) {
                // Forward third-party SMS
                val fwd = "📩 Fwd from $sender:\n$body"
                SmsHelper.sendSms(context, fwd)
                DeviceStatusHelper.saveToLog(context, "Forwarded SMS from $sender")
            }
        }
    }
}
