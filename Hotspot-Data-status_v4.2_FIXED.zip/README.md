# Data Reporter Pro v4.2

Advanced Android background utility for device monitoring, SMS remote control, hotspot management and message forwarding.

## Important – GitHub Upload Instructions

**All files must be at the ROOT of the repository** (not inside any subfolder).

Correct structure after upload:

```
Hotspot-Data-status/          ← repo root
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle
│   └── src/main/...
├── build.gradle
├── settings.gradle
├── gradle.properties
├── README.md
└── .gitignore
```

### How to upload correctly

**Option A – Replace everything (recommended)**
1. Delete all existing files/folders from the GitHub repo (or create a new clean repo).
2. Download the zip provided.
3. Extract it.
4. Upload **the contents** of the extracted folder to the repo root (drag & drop or git push).

**Option B – Using Git**
```bash
git clone https://github.com/YOUR_USER/Hotspot-Data-status.git
cd Hotspot-Data-status
# delete old files
rm -rf *
# copy new files here
git add .
git commit -m "Complete Data Reporter Pro v4.2 source"
git push
```

After push, go to **Actions** tab → the workflow will automatically generate Gradle Wrapper and build the APK.

## Features
- Live battery, network & hotspot status
- Foreground service with persistent notification
- Boot auto-start + optional auto-hotspot
- SMS commands: GET_STATUS, HOTSPOT_ON, HOTSPOT_OFF, 5G_CHECK
- SMS forwarding of third-party messages
- New device detection via ARP
- Local logging
- Material 3 modern UI

## Notes
- Programmatic hotspot toggle is restricted on many modern devices. Reflection is used as best-effort.
- For personal use on your own device.
- Target number should include country code (e.g. +91xxxxxxxxxx).
