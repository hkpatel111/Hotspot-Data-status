package com.hotspot.gateway

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val PREFS = "GatewayPrefs"
    private val PERMISSION_REQUEST = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)
            loadPrefs()
            setupListeners()
            requestNeededPermissions()
            refreshLiveStatus()
        } catch (e: Exception) {
            Toast.makeText(this, "Error loading UI: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun loadPrefs() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        findViewById<EditText>(R.id.etTargetNumber).setText(prefs.getString("target_number", ""))
        findViewById<EditText>(R.id.etInterval).setText(prefs.getInt("interval_mins", 60).toString())
        findViewById<EditText>(R.id.etBootDelay).setText(prefs.getInt("boot_delay", 30).toString())
        findViewById<Switch>(R.id.switchBootHotspot).isChecked = prefs.getBoolean("boot_hotspot_enabled", true)
        findViewById<Switch>(R.id.switchCommands).isChecked = prefs.getBoolean("commands_enabled", true)
        findViewById<Switch>(R.id.switchForward).isChecked = prefs.getBoolean("forward_enabled", true)
    }

    private fun setupListeners() {
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val number = findViewById<EditText>(R.id.etTargetNumber).text.toString().trim()
            if (number.isEmpty()) {
                Toast.makeText(this, "Please enter target mobile number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val interval = findViewById<EditText>(R.id.etInterval).text.toString().toIntOrNull() ?: 60
            val delay = findViewById<EditText>(R.id.etBootDelay).text.toString().toIntOrNull() ?: 30

            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
                putString("target_number", number)
                putInt("interval_mins", interval.coerceIn(5, 1440))
                putInt("boot_delay", delay.coerceIn(5, 300))
                putBoolean("boot_hotspot_enabled", findViewById<Switch>(R.id.switchBootHotspot).isChecked)
                putBoolean("commands_enabled", findViewById<Switch>(R.id.switchCommands).isChecked)
                putBoolean("forward_enabled", findViewById<Switch>(R.id.switchForward).isChecked)
                apply()
            }

            try {
                val serviceIntent = Intent(this, HotspotService::class.java)
                ContextCompat.startForegroundService(this, serviceIntent)
                val statusTv = findViewById<TextView>(R.id.tvServiceStatus)
                statusTv.text = "Service: Running"
                statusTv.setTextColor(ContextCompat.getColor(this, R.color.success))
                Toast.makeText(this, "Settings saved & service started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Service start failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnSendStatus).setOnClickListener {
            try {
                val status = DeviceStatusHelper.getFullStatus(this)
                SmsHelper.sendSms(this, status)
                Toast.makeText(this, "Status SMS queued", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            refreshLiveStatus()
            Toast.makeText(this, "Status refreshed", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnClearLogs).setOnClickListener {
            DeviceStatusHelper.clearLogs(this)
            Toast.makeText(this, "Logs cleared", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshLiveStatus() {
        try {
            val battery = DeviceStatusHelper.getBatteryLevel(this)
            val network = DeviceStatusHelper.getNetworkType(this)
            val hotspot = DeviceStatusHelper.isHotspotEnabled(this)

            findViewById<TextView>(R.id.tvBattery).text = "$battery%"
            findViewById<TextView>(R.id.tvNetwork).text = network
            val hotspotTv = findViewById<TextView>(R.id.tvHotspot)
            hotspotTv.text = if (hotspot) "ON" else "OFF"
            hotspotTv.setTextColor(
                ContextCompat.getColor(this, if (hotspot) R.color.success else R.color.error)
            )
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            findViewById<TextView>(R.id.tvLastUpdate).text = "Last Update: ${sdf.format(Date())}"
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        val perms = mutableListOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        for (p in perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed.add(p)
            }
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), PERMISSION_REQUEST)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshLiveStatus()
    }
}
