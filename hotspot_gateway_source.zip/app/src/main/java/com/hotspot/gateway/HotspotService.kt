package com.hotspot.gateway

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.BufferedReader
import java.io.FileReader
import java.util.*

class HotspotService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private val knownClients = mutableSetOf<String>()
    private val CHANNEL_ID = "HotspotGatewayChannel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Hotspot Gateway Running")
            .setContentText("Monitoring network & clients...")
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .build()
        startForeground(1, notification)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Gateway::Wakelock").apply {
            acquire(10*60*1000L)
        }
        startMonitoringLoop()
    }

    private fun startMonitoringLoop() {
        Timer().scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                checkConnectedClientsAndSendStats()
            }
        }, 0, 60 * 60 * 1000L)
    }

    private fun checkConnectedClientsAndSendStats() {
        val currentClients = getConnectedClientsFromARP()
        for (client in currentClients) {
            if (!knownClients.contains(client)) {
                knownClients.add(client)
                sendSMS("New Device Connected! IP: \$client")
            }
        }
    }

    private fun getConnectedClientsFromARP(): List<String> {
        val clients = mutableListOf<String>()
        try {
            val br = BufferedReader(FileReader("/proc/net/arp"))
            var line: String?
            br.readLine()
            while (true) {
                line = br.readLine() ?: break
                val tokens = line.split(Regex("\\s+"))
                if (tokens.size >= 4) {
                    val ip = tokens[0]
                    val mac = tokens[3]
                    if (mac != "00:00:00:00:00:00") {
                        clients.add(ip)
                    }
                }
            }
            br.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return clients
    }

    fun sendSMS(message: String) {
        val prefs = getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
        val targetNumber = prefs.getString("target_number", null) ?: return
        try {
            val smsManager = android.telephony.SmsManager.getDefault()
            smsManager.sendTextMessage(targetNumber, null, message, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        super.onDestroy()
        wakeLock?.release()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID, "Gateway Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(serviceChannel)
        }
    }
}