package com.hotspot.gateway

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etTargetNumber = findViewById<EditText>(R.id.etTargetNumber)
        val etInterval = findViewById<EditText>(R.id.etInterval)
        val etBootDelay = findViewById<EditText>(R.id.etBootDelay)
        val switchBootHotspot = findViewById<Switch>(R.id.switchBootHotspot)
        val switchCommands = findViewById<Switch>(R.id.switchCommands)
        val btnSave = findViewById<Button>(R.id.btnSave)

        val prefs = getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
        etTargetNumber.setText(prefs.getString("target_number", ""))
        etInterval.setText(prefs.getInt("interval_mins", 60).toString())
        etBootDelay.setText(prefs.getInt("boot_delay", 30).toString())
        switchBootHotspot.isChecked = prefs.getBoolean("boot_hotspot_enabled", true)
        switchCommands.isChecked = prefs.getBoolean("commands_enabled", true)

        btnSave.setOnClickListener {
            val number = etTargetNumber.text.toString().trim()
            val interval = etInterval.text.toString().toIntOrNull() ?: 60
            val delay = etBootDelay.text.toString().toIntOrNull() ?: 30

            if (number.isEmpty()) {
                Toast.makeText(this, "Please enter target mobile number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            prefs.edit().apply {
                putString("target_number", number)
                putInt("interval_mins", interval)
                putInt("boot_delay", delay)
                putBoolean("boot_hotspot_enabled", switchBootHotspot.isChecked)
                putBoolean("commands_enabled", switchCommands.isChecked)
                apply()
            }

            val serviceIntent = Intent(this, HotspotService::class.java)
            startForegroundService(serviceIntent)
            Toast.makeText(this, "Settings Saved & Service Started!", Toast.LENGTH_SHORT).show()
        }
    }
}