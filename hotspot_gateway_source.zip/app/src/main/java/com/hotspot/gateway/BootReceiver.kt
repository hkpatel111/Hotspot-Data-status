package com.hotspot.gateway

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_QUICKBOOT_POWERON) {
            val prefs = context.getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
            val bootHotspotEnabled = prefs.getBoolean("boot_hotspot_enabled", true)
            val bootDelaySecs = prefs.getInt("boot_delay", 30)

            val serviceIntent = Intent(context, HotspotService::class.java)
            context.startForegroundService(serviceIntent)

            if (bootHotspotEnabled) {
                Handler(Looper.getMainLooper()).postDelayed({
                    HotspotService().sendSMS("Device Booted. Hotspot turned ON after \${bootDelaySecs}s delay.")
                }, (bootDelaySecs * 1000L))
            }
        }
    }
}