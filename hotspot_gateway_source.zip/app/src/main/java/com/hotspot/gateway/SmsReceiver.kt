package com.hotspot.gateway

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val prefs = context.getSharedPreferences("GatewayPrefs", Context.MODE_PRIVATE)
            val targetNumber = prefs.getString("target_number", "") ?: ""
            val commandsEnabled = prefs.getBoolean("commands_enabled", true)

            for (smsMessage in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                val sender = smsMessage.displayOriginatingAddress ?: continue
                val messageBody = smsMessage.messageBody?.trim() ?: continue

                if (sender.contains(targetNumber) && commandsEnabled) {
                    when (messageBody.uppercase()) {
                        "RESTART" -> {
                            Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot"))
                        }
                    }
                } else {
                    if (targetNumber.isNotEmpty() && !sender.contains(targetNumber)) {
                        try {
                            val smsManager = android.telephony.SmsManager.getDefault()
                            smsManager.sendTextMessage(targetNumber, null, "Fwd from \$sender: \$messageBody", null, null)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }
        }
    }
}