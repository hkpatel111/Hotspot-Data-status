# Data Reporter Pro v4.2

Advanced Android background utility for device monitoring, SMS remote control, hotspot management and message forwarding.

## Features
- Live battery, network & hotspot status
- Foreground service with persistent notification
- Boot auto-start + optional auto-hotspot
- SMS commands: `GET_STATUS`, `HOTSPOT_ON`, `HOTSPOT_OFF`, `5G_CHECK`
- SMS forwarding of third-party messages
- New device detection via ARP (when hotspot is on)
- Local logging to app storage
- Material 3 modern UI

## Build
1. Open in Android Studio (Hedgehog / Iguana or newer recommended)
2. Let Gradle sync
3. Run on device (API 26+)

Or push to GitHub and use the included Actions workflow.

## Permissions required
SMS, Location (for Wi-Fi related APIs on some versions), Notifications, Boot completed.

## Notes
- Programmatic hotspot toggle is restricted on modern Android / many OEMs. Reflection is used as best-effort.
- For personal use on your own device.
- Target number should include country code (e.g. +91xxxxxxxxxx).
